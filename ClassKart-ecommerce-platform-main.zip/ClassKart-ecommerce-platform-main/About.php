<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us - ClassKart</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background-color: #fff;
            color: #333;
            overflow-x: hidden;
        }

        /* HEADER */
        header {
            background: rgba(255, 255, 255, 0.98);
            padding: 1rem 5%;
            box-shadow: 0 2px 20px rgba(0, 0, 0, 0.08);
            position: sticky;
            top: 0;
            z-index: 1000;
            backdrop-filter: blur(10px);
            transition: all 0.3s ease;
        }

        nav {
            display: flex;
            justify-content: space-between;
            align-items: center;
            max-width: 1400px;
            margin: auto;
        }

        .logo img {
            height: 50px;
            transition: transform 0.3s ease;
        }

        .logo img:hover {
            transform: scale(1.05);
        }

        .nav-links {
            display: flex;
            list-style: none;
            gap: 2.5rem;
        }

        .nav-links a {
            text-decoration: none;
            color: #333;
            font-weight: 500;
            position: relative;
            transition: color 0.3s ease;
        }

        .nav-links a::after {
            content: '';
            position: absolute;
            bottom: -5px;
            left: 0;
            width: 0;
            height: 2px;
            background: #0A5033;
            transition: width 0.3s ease;
        }

        .nav-links a:hover::after,
        .nav-links a.active::after {
            width: 100%;
        }

        .nav-links a:hover,
        .nav-links a.active {
            color: #0A5033;
        }

        .nav-right {
            display: flex;
            align-items: center;
            gap: 1.5rem;
        }

        .search-bar {
            padding: 0.6rem 1.2rem;
            border-radius: 25px;
            border: 1px solid #ddd;
            outline: none;
            transition: all 0.3s ease;
        }

        .search-bar:focus {
            border-color: #0A5033;
            box-shadow: 0 0 0 3px rgba(10, 80, 51, 0.1);
        }

        /* HERO SECTION */
        .hero-about {
            background: linear-gradient(135deg, rgba(10, 80, 51, 0.95), rgba(13, 107, 69, 0.9)),
                        url('images/student.jpg') center/cover;
            text-align: center;
            color: #fff;
            padding: 8rem 5% 6rem;
            position: relative;
            overflow: hidden;
        }

        .hero-about::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: radial-gradient(circle at 20% 50%, rgba(255, 255, 255, 0.1) 0%, transparent 50%);
            animation: pulse 8s ease-in-out infinite;
        }

        @keyframes pulse {
            0%, 100% { opacity: 0.5; }
            50% { opacity: 1; }
        }

        .hero-content {
            position: relative;
            z-index: 1;
            animation: fadeInUp 1s ease;
        }

        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .hero-about h1 {
            font-size: 3.8rem;
            font-weight: 800;
            margin-bottom: 1rem;
            letter-spacing: -1px;
        }

        .hero-about p {
            font-size: 1.4rem;
            max-width: 700px;
            margin: 1rem auto;
            opacity: 0.95;
        }

        /* MAIN CONTENT */
        .about-content {
            max-width: 1400px;
            margin: auto;
            padding: 5rem 5%;
        }

        .about-section {
            margin-bottom: 6rem;
            animation: fadeIn 1s ease;
        }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        .about-section h2 {
            text-align: center;
            font-size: 3rem;
            color: #0A5033;
            margin-bottom: 1.5rem;
            font-weight: 700;
            position: relative;
            display: inline-block;
            left: 50%;
            transform: translateX(-50%);
        }

        .about-section h2::after {
            content: '';
            position: absolute;
            bottom: -10px;
            left: 50%;
            transform: translateX(-50%);
            width: 60px;
            height: 4px;
            background: linear-gradient(90deg, #0A5033, #0d6b45);
            border-radius: 2px;
        }

        .about-section p {
            font-size: 1.15rem;
            color: #666;
            max-width: 900px;
            margin: 2rem auto;
            text-align: center;
            line-height: 1.9;
        }

        /* STORY GRID */
        .story-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 4rem;
            margin-top: 3rem;
            align-items: center;
        }

        .story-text h3 {
            font-size: 2rem;
            color: #0A5033;
            margin-bottom: 1.5rem;
        }

        .story-text p {
            text-align: left;
            margin: 1rem 0;
            font-size: 1.1rem;
            line-height: 1.8;
        }

        .story-image {
            height: 450px;
            background: linear-gradient(135deg, #0A5033 0%, #0d6b45 100%);
            border-radius: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #fff;
            font-size: 5rem;
            box-shadow: 0 20px 60px rgba(10, 80, 51, 0.3);
            transition: transform 0.4s ease, box-shadow 0.4s ease;
            position: relative;
            overflow: hidden;
        }

        .story-image::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle, rgba(255, 255, 255, 0.1) 0%, transparent 70%);
            animation: rotate 20s linear infinite;
        }

        @keyframes rotate {
            from { transform: rotate(0deg); }
            to { transform: rotate(360deg); }
        }

        .story-image:hover {
            transform: translateY(-10px) scale(1.02);
            box-shadow: 0 30px 80px rgba(10, 80, 51, 0.4);
        }

        /* VALUES */
        .values-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
            gap: 2.5rem;
            margin-top: 3rem;
        }

        .value-card {
            background: linear-gradient(135deg, #F8F8F8 0%, #FFFFFF 100%);
            padding: 2.5rem;
            border-radius: 20px;
            text-align: center;
            transition: all 0.4s ease;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.08);
            position: relative;
            overflow: hidden;
        }

        .value-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(10, 80, 51, 0.05), transparent);
            transition: left 0.5s ease;
        }

        .value-card:hover::before {
            left: 100%;
        }

        .value-card:hover {
            transform: translateY(-12px);
            box-shadow: 0 20px 40px rgba(10, 80, 51, 0.2);
            background: linear-gradient(135deg, #FFFFFF 0%, #F8F8F8 100%);
        }

        .value-card h3 {
            font-size: 1.6rem;
            margin-bottom: 1rem;
            color: #0A5033;
            font-weight: 600;
        }

        .value-card p {
            color: #666;
            line-height: 1.7;
        }

        /* STATS */
        .stats-section {
            background: linear-gradient(135deg, #F5F5F5 0%, #FAFAFA 100%);
            padding: 6rem 5%;
            position: relative;
        }

        .stats-grid {
            max-width: 1400px;
            margin: auto;
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 4rem;
            text-align: center;
        }

        .stat-box {
            padding: 2rem;
            transition: transform 0.3s ease;
        }

        .stat-box:hover {
            transform: scale(1.08);
        }

        .stat-number {
            font-size: 3.5rem;
            color: #0A5033;
            font-weight: 800;
            margin-bottom: 0.5rem;
            display: block;
        }

        .stat-box p {
            font-size: 1.1rem;
            color: #666;
            font-weight: 500;
        }

        /* TEAM */
        .team-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(320px, 1fr));
            gap: 3rem;
            margin-top: 3rem;
            justify-items: center;
        }

        .team-card {
            background: #fff;
            border-radius: 20px;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.12);
            overflow: hidden;
            transition: all 0.4s ease;
            max-width: 380px;
            width: 100%;
        }

        .team-card:hover {
            transform: translateY(-15px);
            box-shadow: 0 25px 60px rgba(10, 80, 51, 0.25);
        }

        .team-image {
            height: 320px;
            background: linear-gradient(135deg, #0A5033 0%, #0d6b45 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            color: #fff;
            font-size: 5rem;
            position: relative;
            overflow: hidden;
        }

        .team-image::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            right: 0;
            height: 40%;
            background: linear-gradient(to top, rgba(0, 0, 0, 0.3), transparent);
        }

        .team-info {
            padding: 2.5rem;
            text-align: center;
        }

        .team-info h3 {
            font-size: 1.8rem;
            color: #0A5033;
            margin-bottom: 0.5rem;
            font-weight: 600;
        }

        .team-info p {
            color: #666;
            font-size: 1.1rem;
        }

        /* CTA */
        .cta-section {
            margin: 6rem auto;
            text-align: center;
            padding: 5rem 3rem;
            border-radius: 25px;
            background: linear-gradient(135deg, #0A5033 0%, #0d6b45 100%);
            color: #fff;
            max-width: 1200px;
            position: relative;
            overflow: hidden;
            box-shadow: 0 20px 60px rgba(10, 80, 51, 0.3);
        }

        .cta-section::before {
            content: '';
            position: absolute;
            top: -50%;
            right: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle, rgba(255, 255, 255, 0.1) 0%, transparent 60%);
            animation: rotate 30s linear infinite;
        }

        .cta-section h2 {
            position: relative;
            z-index: 1;
            font-size: 2.5rem;
            margin-bottom: 1rem;
            color: #fff;
        }

        .cta-section h2::after {
            display: none;
        }

        .cta-section p {
            position: relative;
            z-index: 1;
            font-size: 1.2rem;
            margin-bottom: 2rem;
            opacity: 0.95;
            color: #fff;
        }

        .btn-primary {
            position: relative;
            z-index: 1;
            display: inline-block;
            padding: 1.2rem 3rem;
            background: #fff;
            color: #0A5033;
            border-radius: 50px;
            text-decoration: none;
            font-weight: 600;
            font-size: 1.1rem;
            transition: all 0.3s ease;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
        }

        .btn-primary:hover {
            transform: translateY(-3px);
            box-shadow: 0 15px 40px rgba(0, 0, 0, 0.3);
            background: #f0f0f0;
        }

        /* FOOTER */
        footer {
            background: #0A5033;
            color: #fff;
            padding: 5rem 5% 2rem;
        }

        .footer-content {
            max-width: 1200px;
            margin: auto;
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
            gap: 3rem;
        }

        .footer-content h3 {
            font-size: 1.5rem;
            margin-bottom: 1.5rem;
        }

        .footer-content p,
        .footer-content a {
            color: rgba(255, 255, 255, 0.8);
            text-decoration: none;
            display: block;
            margin-bottom: 0.8rem;
            transition: color 0.3s ease;
        }

        .footer-content a:hover {
            color: #fff;
        }

        .footer-bottom {
            text-align: center;
            margin-top: 3rem;
            padding-top: 2rem;
            border-top: 1px solid rgba(255, 255, 255, 0.2);
            color: rgba(255, 255, 255, 0.7);
        }

        /* RESPONSIVE */
        @media(max-width: 768px) {
            .hero-about h1 {
                font-size: 2.5rem;
            }

            .about-section h2 {
                font-size: 2rem;
            }

            .story-grid {
                grid-template-columns: 1fr;
                gap: 2rem;
            }

            .nav-links {
                gap: 1.5rem;
            }

            .stat-number {
                font-size: 2.5rem;
            }

            .cta-section h2 {
                font-size: 2rem;
            }
        }

        @media(max-width: 480px) {
            .nav-links {
                display: none;
            }

            .hero-about {
                padding: 5rem 5% 4rem;
            }
        }
    </style>
</head>
<body>

<!-- HEADER -->
<header>
    <nav>
        <div class="logo">
            <img src="images/logo.png" alt="ClassKart Logo">
        </div>
        <ul class="nav-links">
            <li><a href="index.php">Home</a></li>
            <li><a href="shop.php">Shop</a></li>
            <li><a href="About.html" class="active">About</a></li>
            <li><a href="Contact.html">Contact</a></li>
        </ul>
        <div class="nav-right">
            <input type="text" class="search-bar" placeholder="Search products...">
            <a href="Cart.php">🛒</a>
            <a href="Login.php">Login</a>
        </div>
    </nav>
</header>

<!-- HERO -->
<section class="hero-about">
    <div class="hero-content">
        <h1>About ClassKart</h1>
        <p>Empowering Learning Through Access, Innovation & Community</p>
    </div>
</section>

<!-- MAIN CONTENT -->
<div class="about-content">

    <section class="about-section">
        <h2>Our Mission</h2>
        <p>ClassKart is dedicated to making educational resources accessible, affordable, and of the highest quality for every learner. We believe that education should never be limited by cost or availability, and we're committed to breaking down these barriers one student at a time.</p>
    </section>

    <section class="about-section">
        <h2>Our Story</h2>
        <div class="story-grid">
            <div class="story-text">
                <h3>Where It All Began</h3>
                <p>Founded in 2025 by Alice and Fidele, ClassKart was born from a shared vision and personal experience. As students ourselves, we understood the struggle of finding quality educational materials at affordable prices.</p>
                <p>What started as a simple idea has grown into a thriving platform serving thousands of students. Today, ClassKart stands as a testament to our commitment to educational excellence and accessibility for all.</p>
            </div>
           
        </div>
    </section>

    <section class="about-section">
        <h2>Our Core Values</h2>
        <div class="values-grid">
            <div class="value-card">
                <h3>Quality First</h3>
                <p>We carefully curate every product to ensure learners receive only the best materials that truly support their educational journey.</p>
            </div>
            <div class="value-card">
                <h3>Accessibility</h3>
                <p>Education should be available to everyone. We work tirelessly to keep prices fair and resources within reach.</p>
            </div>
            <div class="value-card">
                <h3>Trust & Support</h3>
                <p>Your success is our success. We're here to support you every step of the way with reliable service and genuine care.</p>
            </div>
            <div class="value-card">
                <h3>Growth & Learning</h3>
                <p>We believe in continuous improvement. As our community grows, so does our commitment to serving you better.</p>
            </div>
        </div>
    </section>

</div>


<

<!-- CTA -->
<section class="cta-section">
    <h2>Join the ClassKart Community</h2>
    <p>Discover quality educational materials, connect with fellow learners, and take your education to the next level.</p>
    <a href="shop.php" class="btn-primary">Start Shopping</a>
</section>

<!-- FOOTER -->
<footer>
    <div class="footer-content">
        <div>
            <h3>ClassKart</h3>
            <p>Quality educational materials for all learners. Empowering students, one resource at a time.</p>
        </div>
        <div>
            <h3>Quick Links</h3>
            <p><a href="index.html">Home</a></p>
            <p><a href="shop.php">Shop</a></p>
            <p><a href="About.html">About Us</a></p>
            <p><a href="Contact.html">Contact</a></p>
        </div>
        <div>
            <h3>Contact Us</h3>
            <p>Email: info@classkart.com</p>
            <p>Phone: +250 XXX XXX XXX</p>
            <p>Kigali, Rwanda</p>
        </div>
    </div>
    <div class="footer-bottom">
        © 2025 ClassKart. All rights reserved.
    </div>
</footer>

</body>
</html>